import { config } from 'dotenv';
config();

import '@/ai/flows/ai-bible-study-companion.ts';
import '@/ai/flows/create-quote-image.ts';
